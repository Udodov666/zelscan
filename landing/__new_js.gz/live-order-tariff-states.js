(function(){
  const backgrounds=[['bg-surface','Поверхность'],['bg-accent','Акцент'],['bg-depth','Глубина']];
  function init(){
    const cards=[...document.querySelectorAll('.zs-t')].slice(0,2);
    if(cards.length!==2||document.getElementById('tariff-background-switch'))return false;
    cards.forEach((card,index)=>{
      const icon=card.querySelector('.zs-t-ic');
      if(icon){
        icon.innerHTML='<img src="gotovo'+(index+1)+'.png" alt="" aria-hidden="true">';
        icon.classList.add('tariff-3d-icon');
      }
      card.classList.add(index?'ts-pro':'ts-basic');
      card.setAttribute('role','button');
      card.setAttribute('tabindex','0');
    });
    const root=cards[0].parentElement;
    let selected=1,background=0;
    const switcher=document.createElement('div');
    switcher.id='tariff-background-switch';
    switcher.innerHTML='<span>Фон</span>'+backgrounds.map((item,index)=>'<button type="button" data-background="'+index+'" aria-pressed="'+(index===0)+'">'+item[1]+'</button>').join('');
    document.body.append(switcher);
    function render(){
      backgrounds.forEach(item=>root.classList.remove(item[0]));
      root.classList.add(backgrounds[background][0]);
      cards.forEach((card,index)=>{
        card.classList.toggle('is-selected',index===selected);
        card.setAttribute('aria-pressed',String(index===selected));
      });
      [...switcher.querySelectorAll('button')].forEach((button,index)=>button.setAttribute('aria-pressed',String(index===background)));
    }
    cards.forEach((card,index)=>{
      card.onclick=()=>{selected=index;render()};
      card.onkeydown=event=>{
        if(event.key==='Enter'||event.key===' '){event.preventDefault();selected=index;render();}
      };
    });
    switcher.onclick=event=>{
      const button=event.target.closest('button[data-background]');
      if(button){background=Number(button.dataset.background);render();}
    };
    render();
    return true;
  }
  let attempts=0;
  const timer=setInterval(()=>{if(init()||++attempts>100)clearInterval(timer)},40);
})();
