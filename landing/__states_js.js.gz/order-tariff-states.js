(function () {
  const modes = [
    ['ts-line', 'Тонкий'],
    ['ts-inner', 'Внутр.'],
    ['ts-double', 'Двойной']
  ];
  function init() {
    const cards = Array.from(document.querySelectorAll('.zs-t')).slice(0, 2);
    if (cards.length !== 2 || document.getElementById('tariff-state-switch')) return false;
    let selected = 1;
    let mode = 0;
    const root = cards[0].parentElement;
    const switcher = document.createElement('div');
    switcher.id = 'tariff-state-switch';
    switcher.innerHTML = '<span>Состояние</span>' + modes.map((x, i) => '<button type="button" data-mode="' + i + '" aria-pressed="' + (i === 0) + '">' + x[1] + '</button>').join('');
    document.body.appendChild(switcher);
    function render() {
      modes.forEach(x => root.classList.remove(x[0]));
      root.classList.add(modes[mode][0]);
      cards.forEach((card, i) => {
        card.classList.toggle('is-selected', i === selected);
        card.setAttribute('aria-pressed', String(i === selected));
        card.setAttribute('tabindex', '0');
      });
      switcher.querySelectorAll('button').forEach((button, i) => button.setAttribute('aria-pressed', String(i === mode)));
    }
    cards.forEach((card, i) => {
      card.addEventListener('click', () => { selected = i; render(); });
      card.addEventListener('keydown', event => {
        if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); selected = i; render(); }
      });
    });
    switcher.addEventListener('click', event => {
      const button = event.target.closest('button[data-mode]');
      if (!button) return;
      mode = Number(button.dataset.mode);
      render();
    });
    render();
    return true;
  }
  let tries = 0;
  const timer = setInterval(() => { if (init() || ++tries > 100) clearInterval(timer); }, 40);
}());
